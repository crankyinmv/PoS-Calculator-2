# PoS-Calculator

This would be a great project to ignore. Just getting my feet wet like a duck. Quack quack.
